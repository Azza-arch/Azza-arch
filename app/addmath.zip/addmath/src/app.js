import { onRouteChange, startRouter } from './utils/router.js';
import { renderStartScreen } from './screens/startScreen.js';
import { renderFormScreen } from './screens/formScreen.js';
import { renderMapScreen } from './screens/mapScreen.js';
import { renderComingSoonScreen } from './screens/comingSoonScreen.js';
import { renderLessonScreen } from './screens/lessonScreen.js';
import { renderPracticeScreen } from './screens/practiceScreen.js';
import { renderChapterScreen } from './screens/chapterScreen.js';
import { renderNoteScreen } from './screens/noteScreen.js';
import { renderNoteV2Screen } from './screens/noteV2Screen.js';

const root = document.getElementById('app');

function render(route) {
  const { name, params } = route;

  switch (name) {
    case 'form':
      renderFormScreen(root);
      break;
    case 'map':
      renderMapScreen(root, Number(params[0]) === 5 ? 5 : 4);
      break;
    case 'soon':
      renderComingSoonScreen(root, params[0]);
      break;
    case 'lesson':
      renderLessonScreen(root, params[0], params[1]);
      break;
    case 'bab':
      renderChapterScreen(root, params[0]);
      break;
    case 'nota':
      renderNoteScreen(root, params[0], params[1], params[2]);
      break;
    case 'nota-v2':
      renderNoteV2Screen(root, params[0], params[1], params[2], params[3]);
      break;
    case 'practice':
      renderPracticeScreen(root, params[0]);
      break;
    case 'start':
    default:
      renderStartScreen(root);
      break;
  }

  root.scrollTop = 0;
  window.scrollTo(0, 0);
}

onRouteChange(render);
startRouter();
