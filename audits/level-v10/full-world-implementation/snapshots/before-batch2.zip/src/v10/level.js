// V10 Batch 1: exact blueprint geometry. Future zones remain data only.
import { MOTION, PUZZLES as ORIGINAL_PUZZLES, SECRETS as ORIGINAL_SECRETS } from '../level.js';
export { MOTION };
export const WORLD = { width:8400, height:1600, gravity:1400 };
export const BATCH_END = 2916;
export const SPAWN = {x:80, feet:1296};
export const GOAL = {x:2820, feet:972}; // review boundary, NOT full-world completion
export const FIRST_GAP = {x:648,width:108};
export const ZONES = [
 {id:'taman-perumahan',name:'A · Taman Pembelajaran',xStart:0,xEnd:1404},
 {id:'lorong-pekan',name:'B · Kincir Fungsi',xStart:1404,xEnd:2916},
 {id:'cafe-atas-angin',name:'C · Café Atas Angin (pilihan)',xStart:1512,xEnd:1944,yMax:870}
];
export const SURFACES = [
  {
    "id": "A0",
    "x": 0,
    "y": 1296,
    "width": 648,
    "kind": "solid",
    "zone": "A",
    "gate": null
  },
  {
    "id": "A1",
    "x": 756,
    "y": 1296,
    "width": 270,
    "kind": "solid",
    "zone": "A",
    "gate": null
  },
  {
    "id": "A2",
    "x": 1026,
    "y": 1242,
    "width": 108,
    "kind": "solid",
    "zone": "A",
    "gate": null
  },
  {
    "id": "A3",
    "x": 1134,
    "y": 1188,
    "width": 108,
    "kind": "solid",
    "zone": "A",
    "gate": null
  },
  {
    "id": "A4",
    "x": 1242,
    "y": 1134,
    "width": 162,
    "kind": "solid",
    "zone": "A",
    "gate": null
  },
  {
    "id": "A-ledge",
    "x": 414,
    "y": 1176,
    "width": 162,
    "kind": "optional",
    "zone": "A",
    "gate": null
  },
  {
    "id": "B0",
    "x": 1404,
    "y": 1134,
    "width": 270,
    "kind": "solid",
    "zone": "B",
    "gate": null
  },
  {
    "id": "B1",
    "x": 1674,
    "y": 1080,
    "width": 108,
    "kind": "solid",
    "zone": "B",
    "gate": null
  },
  {
    "id": "B2",
    "x": 1782,
    "y": 1080,
    "width": 270,
    "kind": "solid",
    "zone": "B",
    "gate": null
  },
  {
    "id": "G1",
    "x": 2052,
    "y": 1080,
    "width": 324,
    "kind": "gate",
    "zone": "B",
    "gate": "gear"
  },
  {
    "id": "B3",
    "x": 2376,
    "y": 1080,
    "width": 216,
    "kind": "solid",
    "zone": "B",
    "gate": null
  },
  {
    "id": "B4",
    "x": 2592,
    "y": 1026,
    "width": 108,
    "kind": "solid",
    "zone": "B",
    "gate": null
  },
  {
    "id": "B5",
    "x": 2700,
    "y": 972,
    "width": 216,
    "kind": "solid",
    "zone": "B",
    "gate": null
  },
  {
    "id": "C0",
    "x": 1512,
    "y": 810,
    "width": 432,
    "kind": "optional",
    "zone": "C",
    "gate": null
  }
];
export const AB_TERRAIN = SURFACES.filter(s=>s.kind==='solid');
export const DECKS = SURFACES.filter(s=>s.id==='C0');
export const GROUND_RANGES = [[0,648],[756,2052],[2376,2916]];
export const LADDERS = [
 {id:'LC-in',x:1566,top:810,bottom:1134},
 {id:'LC-out',x:1836,top:810,bottom:1080}
];
export const GATES = [{id:'gear',x:2052,y:1080,width:324}];
export const TERMINALS = [
 {id:'probe',kind:'probe',x:1480,feet:1134},
 {id:'p1',kind:'gear',gate:'gear',x:1960,feet:1080},
 {id:'cafe',kind:'mapping',x:1740,feet:810}
];
export const CHECKPOINTS = [
 {id:'cp-a',x:1080,feet:1242},
 {id:'cp-b',x:1900,feet:1080},
 {id:'cp-c',x:1620,feet:810,optional:true},
 {id:'cp-b-exit',x:2790,feet:972,requires:'gear'}
];
export const COLLECTIBLES = [
 {id:'coin-a',x:500,y:1112}, {id:'coin-b',x:2520,y:1020}, {id:'coin-c',x:1880,y:750}
];
export const SECRETS = [{...ORIGINAL_SECRETS[0],x:1900,feet:810,radius:48}];
export const CRATE_PUZZLE = {
 crate:{id:'crate-1',x:270,feet:1296}, floorSwitch:{id:'switch-1',x:450,feet:1296,radius:40},
 platform:{id:'A-ledge',x:414,y:1176,width:162}
};
export const PUZZLES = [{...ORIGINAL_PUZZLES[0],gate:'gear'}];
export const BASELINE_QUESTIONS = ORIGINAL_PUZZLES; // p2/p3 preserved for later batches
