import { CHECKPOINTS, COLLECTIBLES, SECRETS } from './level.js';
import { SaveManager as Legacy } from '../save.js';
const STORAGE_KEY='lorong-save-v10';
const LEVEL_ID='lorong-atas-bumbung-v10';
const ids=(raw,allowed)=>Array.isArray(raw)?[...new Set(raw.filter(x=>allowed.includes(x)))]:[];
export function sanitize(raw) {
  if(!raw||raw.schemaVersion!==3||raw.layoutVersion!==10||raw.levelId!==LEVEL_ID)return null;
  const solvedGateIds=ids(raw.solvedGateIds,['gear']);
  const cp=CHECKPOINTS.find(c=>c.id===raw.checkpointId);
  const checkpointId=cp&&(!cp.requires||solvedGateIds.includes(cp.requires))?cp.id:null;
  const mappingInputs=ids(raw.mappingInputs,[0,1,2,3]);
  return {schemaVersion:3,layoutVersion:10,levelId:LEVEL_ID,checkpointId,solvedGateIds,
    collectedCoinIds:ids(raw.collectedCoinIds,COLLECTIBLES.map(c=>c.id)),
    discoveredSecretIds:ids(raw.discoveredSecretIds,SECRETS.map(s=>s.id)),
    mappingInputs,mappingDone:mappingInputs.length===4,
    finalLatches:{input:raw.finalLatches?.input===true,composition:raw.finalLatches?.composition===true},
    legacyProgress:raw.legacyProgress&&typeof raw.legacyProgress==='object'?raw.legacyProgress:null,
    batch1Completed:raw.batch1Completed===true&&solvedGateIds.includes('gear'),completed:false,
    updatedAt:Number.isFinite(raw.updatedAt)?raw.updatedAt:0};
}
export const SaveManager={
  STORAGE_KEY,LEVEL_ID,SCHEMA_VERSION:3,
  load(){try{return sanitize(JSON.parse(localStorage.getItem(STORAGE_KEY)));}catch{return null;}},
  save(snapshot){try{const data=sanitize({...snapshot,schemaVersion:3,layoutVersion:10,levelId:LEVEL_ID});if(!data)return false;localStorage.setItem(STORAGE_KEY,JSON.stringify(data));return true;}catch{return false;}},
  clear(){try{localStorage.removeItem(STORAGE_KEY);}catch{}},
  legacyAvailable(){return !!Legacy.load();},
  importLegacy(){
    if(this.load())return false;
    const old=Legacy.load();if(!old)return false;
    const gear=old.solvedGateIds.includes('workshop-gate');
    return this.save({checkpointId:gear?'cp-b':old.checkpointId==='cp1-cafe'?'cp-c':null,
      solvedGateIds:gear?['gear']:[],collectedCoinIds:old.collectedCoinIds,discoveredSecretIds:old.discoveredSecretIds,
      finalLatches:{input:old.solvedGateIds.includes('final-gate'),composition:false},
      legacyProgress:old,updatedAt:Date.now()});
  }
};
