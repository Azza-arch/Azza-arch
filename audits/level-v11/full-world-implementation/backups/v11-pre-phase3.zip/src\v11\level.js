// V11.1 Phase 1 only. Geometry differs intentionally from V10; no old coordinates migrate.
import {MOTION,PUZZLES as ORIGINAL_PUZZLES} from '../level.js';
export {MOTION};
export const WORLD={width:8400,height:1600,gravity:1400};
export const BUILD_STAGE=2, BATCH_END=4104;
export const SPAWN={x:90,feet:1296},GOAL={x:2940,feet:972};
export const FIRST_GAP={x:1080,width:108};
export const ROOMS=[
 {id:'R01',zone:'A',from:0,to:432,name:'Langkah pertama'},
 {id:'R02',zone:'A',from:432,to:972,name:'Kotak dan plet',optional:true},
 {id:'R03',zone:'A',from:972,to:1458,name:'Jurang dan checkpoint'},
 {id:'R04',zone:'B',from:1458,to:1944,name:'Mendaki dan mencuba input'},
 {id:'R05',zone:'B',from:1944,to:2484,name:'Pengangkat fungsi'},
 {id:'R06',zone:'C',from:1458,to:1944,name:'Bonus atas',optional:true},
 {id:'R07',zone:'B',from:2484,to:3024,name:'Menuju blok nombor'}];
ROOMS.push(
 {id:'R08',zone:'D',from:3024,to:3564,name:'Blok nombor'},
 {id:'R09',zone:'D',from:3100,to:3456,name:'Laluan servis',optional:true},
 {id:'R10',zone:'D',from:3834,to:4104,name:'Susunan fungsi'});
export const SURFACES=[
 {id:'A-start',x:0,y:1296,width:270,kind:'solid',room:'R01'},
 {id:'A-step',x:270,y:1242,width:162,kind:'solid',room:'R01'},
 {id:'A-crate',x:432,y:1242,width:648,kind:'solid',room:'R02'},
 {id:'A-landing',x:1188,y:1242,width:270,kind:'solid',room:'R03'},
 {id:'B-low',x:1458,y:1188,width:162,kind:'solid',room:'R04'},
 {id:'B-middle',x:1620,y:1134,width:216,kind:'solid',room:'R04'},
 {id:'B-control',x:1836,y:1080,width:324,kind:'solid',room:'R05'},
 {id:'B-lift',x:2160,y:1080,width:324,kind:'gate',room:'R05'},
 {id:'B-bank',x:2484,y:1080,width:162,kind:'solid',room:'R07'},
 {id:'B-terrace',x:2646,y:1026,width:162,kind:'solid',room:'R07'},
 {id:'B-overlook',x:2808,y:972,width:216,kind:'solid',room:'R07'},
 {id:'D-approach',x:3024,y:972,width:540,kind:'solid',room:'R08'},
 {id:'D-crossing',x:3564,y:972,width:270,kind:'gate',room:'R08'},
 {id:'D-landing',x:3834,y:972,width:270,kind:'solid',room:'R10'},
 {id:'D-rack',x:3078,y:918,width:216,kind:'oneWay',room:'R08'},
 {id:'D-service',x:3294,y:738,width:216,kind:'oneWay',room:'R09',optional:true},
 {id:'C-route',x:1458,y:864,width:486,kind:'oneWay',room:'R06'},
 {id:'A-ledge',x:774,y:1122,width:162,kind:'optional',room:'R02'}];
export const AB_TERRAIN=SURFACES.filter(s=>s.kind==='solid');
export const DECKS=SURFACES.filter(s=>s.kind==='oneWay');
export const GROUND_RANGES=AB_TERRAIN.map(s=>[s.x,s.x+s.width]);
export const LADDERS=[{id:'C-entry',x:1512,top:864,bottom:1188},{id:'C-return',x:1890,top:864,bottom:1080},{id:'D-service',x:3330,top:738,bottom:972}];
export const GATES=[{id:'lift',x:2160,y:1080,width:324,parkedY:1296},{id:'number-span',x:3564,y:972,width:270,parkedY:1188}];
export const TERMINALS=[{id:'probe',kind:'probe',x:1692,feet:1134},{id:'lift',kind:'lift',gate:'lift',x:2070,feet:1080},{id:'mapping',kind:'mapping',x:1692,feet:864},{id:'number',kind:'number',gate:'number-span',x:3420,feet:972},{id:'composition',kind:'composition',x:3960,feet:972}];
export const CHECKPOINTS=[{id:'a-safe',x:378,feet:1242},{id:'a-gap',x:1296,feet:1242},{id:'b-lift',x:2000,feet:1080},{id:'c-bonus',x:1566,feet:864},{id:'b-review',x:2916,feet:972,requires:['lift']},{id:'d-machine',x:3294,feet:972},{id:'d-crossing',x:3915,feet:972,requires:['number-span']}];
export const COLLECTIBLES=[{id:'a-ledge',x:855,y:1062},{id:'c-entry',x:1566,y:804},{id:'c-return',x:1836,y:804},{id:'b-return',x:2556,y:1020},{id:'d-service',x:3402,y:696}];
export const CRATE_PUZZLE={crate:{id:'crate-1',x:540,feet:1242},floorSwitch:{id:'plate-1',x:810,feet:1242,radius:40},platform:SURFACES.find(s=>s.id==='A-ledge')};
export const SECRETS=[{id:'bonus-mapping',x:1782,feet:864,radius:36,name:'Permata Pemetaan',description:'Terokai empat pasangan input dan output di laluan atas.',foundText:'Permata pemetaan diperoleh!'}];
export const BASELINE_QUESTIONS=ORIGINAL_PUZZLES;
const numberPuzzle={id:'number',gate:'number-span',check(raw){const value=Number(raw);return {valid:Number.isInteger(value)&&value>=2&&value<=4,correct:Number.isInteger(value)&&value===4};}};
export const PUZZLES=[{...ORIGINAL_PUZZLES[0],gate:'lift'},numberPuzzle];
export const ZONES=[{name:'A · Taman Permulaan',xStart:0,xEnd:1458},{name:'B · Bukit & Pengangkat',xStart:1458,xEnd:3024},{name:'C · Bonus Atas',xStart:1458,xEnd:1944,yMax:900},{name:'D · Blok Nombor',xStart:3024,xEnd:4104}];
